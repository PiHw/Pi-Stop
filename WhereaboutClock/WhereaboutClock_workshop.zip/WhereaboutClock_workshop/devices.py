# Edit the file for the people/devices you want to track
class ident():
    #-1=No Display
    IGNORE    = -1
    Home      = -1
    Me        = 0
    John      = 1
    Jane      = 2
    WARN      = 5

home = [
    {"name":"TV",               "mac":"00:03:78:ad:ba:ca",      "ident":ident.Home},
    {"name":"Network NAS",      "mac":"6c:72:20:05:54:45",      "ident":ident.Home},
    {"name":"DVD Player",       "mac":"b8:27:eb:44:0d:55",      "ident":ident.Home},
    {"name":"John Laptop",      "mac":"ac:b5:7d:88:21:77",      "ident":ident.John},
    {"name":"Jane Laptop",      "mac":"f8:3d:ff:43:ee:34",      "ident":ident.Jane},
    {"name":"My Laptop",        "mac":"a0:8e:78:2e:2e:e2",      "ident":ident.Me},
    {"name":"My Phone",         "mac":"00:08:22:bf:ba:b3",      "ident":ident.Me},
    {"name":"Home Printer",     "mac":"ec:9b:f3:7a:7a:7a",      "ident":ident.Home},
    {"name":"John Phone",       "mac":"00:1d:fe:cd:cd:cd",      "ident":ident.John},
    {"name":"Jane Phone",       "mac":"fc:a6:67:44:22:11",      "ident":ident.Jane},
    {"name":"Bob Tablet",       "mac":"84:b5:41:00:88:66",      "ident":ident.IGNORE},
    {"name":"Jane Tablet",      "mac":"34:d2:70:36:63:36",      "ident":ident.Jane},
    {"name":"Home Gateway",     "mac":"ac:bd:ce:df:e1:f2",      "ident":ident.Home}
    ]
