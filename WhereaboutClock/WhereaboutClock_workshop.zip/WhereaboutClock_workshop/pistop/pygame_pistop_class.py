#!/usr/bin/python3
import sys
import os.path
import pygame


G,Y,R=g,y,r=0,1,2
OFF,ON=off,on=0,1

ALL=all=(G,Y,R)

RPI_REVISION=3

PISTOP_W = 103
PISTOP_H = 458

#Set DEBUG to True to display pins and status information
DEBUG=False

#Hardware Setup
location={"A":[22,24,26],
          "B":[23,21,19],
          "C":[8,10,12],
          "D":[7,5,3]}
locPlus={"A+":[36,38,40],
         "B+":[37,35,33]}
location=dict(list(location.items())+list(locPlus.items()))

DEFAULT_ORDER = ["A+","A","C","D","B","B+"]

BOARD=1
OUT,IN=1,0

iON = [pygame.image.load(os.path.join("pistop","G.png")),
       pygame.image.load(os.path.join("pistop","Y.png")),
       pygame.image.load(os.path.join("pistop","R.png"))]
rect = [iON[G].get_rect(),
        iON[Y].get_rect(),
        iON[R].get_rect()]

pistop = pygame.image.load(os.path.join("pistop","pi-Stop.png"))
pistoprect = pistop.get_rect()


class pistopsim():
    def __init__(self,location=None,order=None):
        if location is None:
            print("No pins defined")
            self.location = {"A":[22,24,26]}
        else:
            self.location = location
        if order is None:
            self.order = DEFAULT_ORDER
        else:
            self.order = order
        self.status = []
        self.pins=[]
        self.pistoppos = []

        for number,loc in enumerate(self.order):
            self.pins.append(location[loc])      #Set location of pins
            self.status.append([OFF,OFF,OFF])    #Set pin status to OFF
            self.pistoppos.append((PISTOP_W*number,0))   #Define position of PiStop display

        pygame.init()
        size = width, height = PISTOP_W*len(self.pins), PISTOP_H
        black = 0, 0, 0
        white = 255, 255, 255
        self.screen = pygame.display.set_mode(size)
        self.screen.fill(white)

    def output(self,pin,state):
        if DEBUG:print("Pin:%s State:%s" %(pin,state))
        for number, pistop_pins in enumerate(self.pins):
            for i,val in enumerate(pistop_pins):
                if val==pin:
                    self.status[number][i]=state
        if DEBUG:print(self.status)
        self.update()

    def update(self):
        for number,pos in enumerate(self.pistoppos):
            self.screen.blit(pistop, pistoprect.move(pos[0],
                                                     pos[1]))
            for i in ALL:
              if self.status[number][i]==ON:
                self.screen.blit(iON[i], rect[i].move(pos[0],
                                                      pos[1]))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT: sys.exit()

def setmode(mode):
    pass

def setup(pin,mode):
    pass

def cleanup():
    pygame.quit()

def setwarnings(set):
    pass

def output(pin,state):
    installed.output(pin,state)

if __name__ == '__main__':
  import time
  while 1:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: sys.exit()

    output(22,ON)
    output(21,ON)
    output(38,ON)
    output(33,ON)
    time.sleep(1)
    output(22,OFF)
    output(21,OFF)
    output(38,OFF)
    output(33,OFF)
    time.sleep(1)