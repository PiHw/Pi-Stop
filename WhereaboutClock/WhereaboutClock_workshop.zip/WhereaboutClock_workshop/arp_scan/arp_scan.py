#!/usr/bin/python3
import platform
import random
import subprocess
import os.path

DEBUG=False
PATH="arp_scan"
SIM_ITEMS = 6

if "Windows1" == platform.system():
    DEFAULT_OS = "windows"
else:
    DEFAULT_OS = "linux"

class ArpScanner():
    IP,MAC=0,1
    def scan():
        if DEBUG:print("ARP-Scan program.")

    def scanMOCK(os_name=DEFAULT_OS):
        print("SIMULATION")
        header_file=os.path.join(PATH, os_name+"_arp_scan_header.txt")
        output_file=os.path.join(PATH, os_name+"_arp_scan_output.txt")
        footer_file=os.path.join(PATH, os_name+"_arp_scan_footer.txt")
        with open(header_file, 'r', newline='') as file:
            header = file.read()
        with open(output_file, 'r', newline='') as file:
            outlines = file.readlines()
        with open(footer_file, 'r', newline='') as file:
            footer = file.read()
        output=header+"\n"
        for i in range(SIM_ITEMS):
            output=output+outlines[random.randrange(len(outlines))]
        output=output+footer
        return output

    def parseResponse(response):
        ''' We know scan data starts on line 3 and there is a blank line before the footer.
            The data is IP address followed by space, the MAC address and then manufacturer info.
            If each line is split with spaces we are only interested in the first two items.

            Linux:
            192.168.1.4    ac:bd:ce:df:e1:f2    Device Manufacturer Info

            Windows:
            Internet Address      Physical Address      Type
            192.168.1.100         6c-72-20-05-3a-5b     dynamic 
        '''
        seen=[]
        arp_lines=response.splitlines()
        #Ensure we have device data to read
        if len(arp_lines) > 5:
            arp_lines.pop(0) #Discard header info
            arp_lines.pop(0) #Discard header info
            if "Internet Address" in arp_lines[0]:
                arp_lines.pop(0) #Discard header info
            #Check each arp line
            for line in arp_lines:
                if line.strip() == "":
                    break #End of device list
                elif "static" in line:
                    break #Ignore static addresses
                else:
                    #Split lines
                    seen_device=str.replace(line,"-",":").split()[0:2]

                    #Ensure MAC has not already been seen
                    unique=True
                    for item in seen:
                        if seen_device[ArpScanner.MAC] == item[ArpScanner.MAC]:
                            unique=False
                            if DEBUG:print("Duplicated MAC")
                    if unique:
                        #Add to seen device list
                        seen.append(seen_device)
        return seen

class ArpScanLinux(ArpScanner):
    def scan():
        '''Linux ARP Scanning program.'''
        try:
            binoutput = subprocess.check_output("sudo arp-scan -l -r 10", shell=True)
            output = binoutput.decode()
        except subprocess.CalledProcessError:
            print("Error: Arp-Scan may not be installed or experienced an error running")
            output=ArpScanner.scanMOCK(os_name="linux")
        return output

class ArpScanWin(ArpScanner):
    def scan():
        '''Windows ARP Scanning program.'''
        try:
            output_raw = subprocess.check_output("arp -a", shell=True)
            #Convert bytes to string if required
            if isinstance(output_raw, bytes):
                output = str(output_raw, 'utf-8')
        except subprocess.CalledProcessError:
            print("Error: Arp-Scan may not be installed or experienced an error running")
            output=ArpScanner.scanMOCK(os_name="windows")
            print(output)
        return output

if __name__=="__main__":
    import platform
    if "Windows" == platform.system():
        SCAN = ArpScanWin
    else:
        SCAN = ArpScanLinux
    SCAN.scan()