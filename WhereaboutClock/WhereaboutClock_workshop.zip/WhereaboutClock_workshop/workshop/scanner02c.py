#!/usr/bin/python3
from time import sleep
import pistop.display as DISP
from arp_scan.arp_scan import ArpScanLinux as SCAN
import devices

SCAN_PERIOD = 10 #seconds

run = True
with DISP.display(hw_id=["A","C"]) as myDisplay:
    while(run):
        try:
            print("SCANNING...")
            ###Your code here###
            response = SCAN.scanMOCK()
            seen = SCAN.parseResponse(response)
            myDisplay.demoLine()
            # Check if seen items are expected
            for itemseen in seen:
                name = "UNKNOWN"
                ident = devices.ident.WARN
                mac = itemseen[SCAN.MAC]
                ip = itemseen[SCAN.IP]
                for item in devices.home:
                    if item["mac"] in itemseen[SCAN.MAC]:
                        name = item["name"]
                        ident = item["ident"]
                        break
                # Display active devices
                print("#{:<2} {:<17}\t{:15}\t({})".format(ident, mac, ip, name))
                myDisplay.pos(ident, DISP.PS.ON, vertical=True)
            sleep(SCAN_PERIOD)
        except KeyboardInterrupt:
            # On keyboard interrupt signal stop running
            run = False
print("End")
