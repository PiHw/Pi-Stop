#!/usr/bin/python3
from time import sleep
import pistop.display as DISP
from arp_scan.arp_scan import ArpScanLinux as SCAN

SCAN_PERIOD = 10 #seconds

run = True
with DISP.display(hw_id=["A"]) as myDisplay:
    while(run):
        try:
            print("SCANNING...")
            ###Your code here###
            response = SCAN.scanMOCK()
            print(response)
            myDisplay.demoLine()
            sleep(SCAN_PERIOD)
        except KeyboardInterrupt:
            # On keyboard interrupt signal stop running
            run = False
print("End")
