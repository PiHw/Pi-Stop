#!/usr/bin/python3

from time import sleep
import devices


PISTOP_FITTED=True
if PISTOP_FITTED:
  import pistop.display as DISP

import platform
if "Windows" == platform.system():
    from arp_scan.arp_scan import ArpScanWin as SCAN
else:
    from arp_scan.arp_scan import ArpScanLinux as SCAN

SCAN_PERIOD = 10 #seconds
SCAN_CHANCE = 5  #seen for x number of scans
DEBUG=False
LOG_FILE="unknown.log"

def writeToLog(text,log_file=LOG_FILE):
  with open(log_file, 'a') as file:
    file.write("{}".format(text))



class scanner():
  def __init__(self, devices=devices.home, enableDisplay=PISTOP_FITTED, DEBUG=False):
    '''Init scanner'''
    self.DEBUG=DEBUG
    if enableDisplay:
      #Enable display
      self.disp = DISP.display(hw_id=("A"))
    #Load device dictionary to monitor
    self.devices=devices

  def __enter__(self):
    '''Enter scanner'''
    #Add seen counter to device dictionary
    for item in self.devices:
      item["counter"] = 0
    return self
    
  def __exit__(self,type,value,traceback):
    '''Exit scanner'''
    if self.disp != None:
      self.disp.__exit__(None,None,None)

  def performScan(self):
    '''Perform a scan of the network using arp-scan'''
    #ARP Scan for devices
    print("SCANNING...")
    response = SCAN.scan()
    seen=SCAN.parseResponse(response)
    if self.DEBUG:print(seen)
    #Show scanning activity on the display
    if self.disp != None:
      self.disp.demoSpin()
      self.disp.demoSpin(cw=False)
    return seen

  def checkDevices(self,seen):
    '''Check if seen items are expected'''
    for itemseen in seen:
      if self.DEBUG:print("DEBUG: ")
      if self.DEBUG:print(itemseen)
      unknown=True
      #Refresh the seen counter for a device
      for item in self.devices:
        #Device seen matches list
        if item["mac"] in itemseen[SCAN.MAC]:
          if self.DEBUG:print("Found: {}".format(item["name"]))
          item["counter"]=SCAN_CHANCE
          item["ip"]=itemseen[SCAN.IP]
          unknown=False
          break;
      #Device not known?
      if unknown:
        #Device does not match list (so add)
        unknown_device={"name"    : "UNKNOWN",
                        "mac"     : itemseen[SCAN.MAC],
                        "ident"   : devices.ident.WARN,
                        "ip"      : itemseen[SCAN.IP],
                        "counter" : SCAN_CHANCE}
        print("UNKNOWN device")
        print(unknown_device)
        if LOG_FILE!=None:
          writeToLog(unknown_device)
        self.devices.append(unknown_device)
      if self.DEBUG:print("Seen Devices: {}".format(len(self.devices)))

  def displayDevices(self):
    '''Display the devices seen'''
    print("Display devices seen")
    for item in self.devices:
      if item.get("counter",0) > 0:
        mac = item["mac"]
        name = item["name"]
        ident = item["ident"]
        ip = item["ip"]
        counter = item["counter"]
        #Display active devices
        print("#{} [{}] {:<17}\t{:<15}\t({})".format(ident,counter,mac,ip,name))
        if self.disp != None:
          self.disp.pos(ident-1,DISP.PS.ON,vertical=True)
        #Decrease seen counter
        item["counter"]=item["counter"]-1

if __name__=="__main__":
  with scanner(DEBUG=False) as homeScanner:
    run = True
    while(run):
      try:
        #Perform scan
        seen=homeScanner.performScan()
        #Check if seen items are expected
        homeScanner.checkDevices(seen)
        #Display the devices seen
        homeScanner.displayDevices()
        #Wait for next scan
        sleep(SCAN_PERIOD)
      except KeyboardInterrupt:
        # On a keyboard interrupt stop scanning
        run = False
